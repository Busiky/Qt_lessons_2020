from PIL import Image
from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QCheckBox
from PyQt5.QtWidgets import QPushButton, QLineEdit, QLabel
from PyQt5.QtGui import QPixmap
import sys

SCREEN_SIZE = [400, 400]


class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setGeometry(400, 400, *SCREEN_SIZE)
        self.setWindowTitle('Отображение картинки')
        self.btn = QPushButton(self)
        self.btn.setText('Rotate')
        self.btn.move(10, 10)
        self.start = 'star.png'
        self.filename = 'star.png'

        self.check = QCheckBox(self)
        self.check.setObjectName('R')
        self.check_2 = QCheckBox(self)
        self.check_2.setObjectName('G')
        self.check_3 = QCheckBox(self)
        self.check_3.setObjectName('B')
        self.check.move(350, 10)
        self.check_2.move(350, 40)
        self.check_3.move(350, 70)

        self.label = QLabel(self)
        self.label_2 = QLabel(self)
        self.label_3 = QLabel(self)
        self.label.move(380, 10)
        self.label.setText('R')
        self.label_2.move(380, 40)
        self.label_2.setText('G')
        self.label_3.move(380, 70)
        self.label_3.setText('B')

        self.btn.clicked.connect(self.rotate)

        self.list_to_show = []

        self.pixmap = QPixmap(self.filename)
        self.image = QLabel(self)
        self.image.move(80, 60)
        self.image.resize(250, 250)
        self.image.setPixmap(self.pixmap)

        self.check.stateChanged.connect(self.clickBox)
        self.check_2.stateChanged.connect(self.clickBox)
        self.check_3.stateChanged.connect(self.clickBox)

    def clickBox(self, state):
        if state == QtCore.Qt.Checked:
            self.list_to_show.append(self.sender().objectName())
        else:
            self.list_to_show.pop(self.list_to_show.index(self.sender().objectName()))

        if not self.list_to_show:
            self.filename = self.start

        im = Image.open(self.filename)
        pixels = im.load()
        x, y = im.size
        red = green = blue = True
        if 'R' in self.list_to_show:
            red = False
        if 'G' in self.list_to_show:
            green = False
        if 'B' in self.list_to_show:
            blue = False

        for i in range(x):
            for j in range(y):
                r, g, b, a = pixels[i, j]
                if not red:
                    r = 0
                if not green:
                    g = 0
                if not blue:
                    b = 0
                pixels[i, j] = r, g, b, a
        if self.filename[0] == '1':
            im.save(self.filename)
        else:
            im.save('1' + self.filename)
            self.filename = '1' + self.filename

        self.pixmap = QPixmap(self.filename)
        self.image.setPixmap(self.pixmap)

    def rotate(self):
        im = Image.open(self.filename)
        if self.filename[0] == '1':
            im.save(self.filename)
        else:
            im.save('1' + self.filename)
            self.filename = '1' + self.filename

        im_new = im.transpose(Image.FLIP_LEFT_RIGHT).transpose(Image.ROTATE_90)
        im_new.save(self.filename)
        self.pixmap = QPixmap(self.filename)
        self.image.setPixmap(self.pixmap)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec())
